package com.example.ana.aapp.Fragmenti;

import android.support.v4.app.Fragment;

/**
 * Created by Ana on 6/5/2017.
 */

public class BidFragment extends Fragment{

}

